<?php

	include('./WS/WSClientInfoMares.php');	
	
	
	function validateUser($username,$password)
		{
			$wsClienteMares = new WSClientInfoMares();
			
			$res = false;
			
			$username = strtolower($username);
			
							
			if (is_numeric($username)){

				try{
					$wsClienteMares->validarUsuario($username,$password);
				}catch(TException $e){
					//ERROR EN EL SERVICIO WEB;
				}

				//espera a que termina la ejecucion del servicio web y que el resultado sea valido
				while (!$wsClienteMares->terminoSOAP);

				if($wsClienteMares->IsUserValid){
					echo "EL USUARIO Y CLAVE SON VALIDOS";	
				}

				return $res;
			}

			return $res;
		}
		
		//RECEPCION DE DATOS POR POST
		
		//Llamado a función de validación	
		
		validateUser($usuario, $clave);
		
		
		
?>